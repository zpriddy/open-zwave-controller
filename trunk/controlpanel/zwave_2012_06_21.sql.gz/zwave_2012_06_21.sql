-- 
-- Structure for table `tbl_admin`
-- 

DROP TABLE IF EXISTS `tbl_admin`;
CREATE TABLE IF NOT EXISTS `tbl_admin` (
  `idtbladmin` int(11) NOT NULL,
  `username` varchar(45) NOT NULL,
  `password` varchar(128) NOT NULL,
  PRIMARY KEY (`idtbladmin`),
  UNIQUE KEY `username` (`username`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- 
-- Structure for table `tbl_floors`
-- 

DROP TABLE IF EXISTS `tbl_floors`;
CREATE TABLE IF NOT EXISTS `tbl_floors` (
  `idtbl_floor` int(11) NOT NULL AUTO_INCREMENT,
  `tbl_floor` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`idtbl_floor`)
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;

-- 
-- Structure for table `tbl_rooms`
-- 

DROP TABLE IF EXISTS `tbl_rooms`;
CREATE TABLE IF NOT EXISTS `tbl_rooms` (
  `idtbl_rooms` int(11) NOT NULL AUTO_INCREMENT,
  `tbl_room` varchar(100) DEFAULT NULL,
  `tbl_floorId` int(11) DEFAULT NULL,
  PRIMARY KEY (`idtbl_rooms`)
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;

-- 
-- Structure for table `tbl_schedules`
-- 

DROP TABLE IF EXISTS `tbl_schedules`;
CREATE TABLE IF NOT EXISTS `tbl_schedules` (
  `idtbl_schedules` int(11) NOT NULL AUTO_INCREMENT,
  `schedule_summary` varchar(100) DEFAULT NULL,
  `schedule_off` varchar(255) CHARACTER SET utf8 NOT NULL,
  `schedule_on` varchar(255) CHARACTER SET utf8 NOT NULL,
  `schedule_repeat` varchar(255) CHARACTER SET utf8 NOT NULL,
  PRIMARY KEY (`idtbl_schedules`)
) ENGINE=MyISAM AUTO_INCREMENT=65 DEFAULT CHARSET=latin1;

